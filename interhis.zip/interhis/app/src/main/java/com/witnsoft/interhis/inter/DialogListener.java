package com.witnsoft.interhis.inter;

public interface DialogListener {
    public void refreshActivity(Object object);
}